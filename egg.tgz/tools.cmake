# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(stream_join src/stream_join.cpp)
set_property(TARGET stream_join PROPERTY CXX_STANDARD 11)
target_link_libraries(stream_join lionss pthread)

add_executable(resume_parse src/resume_parse.cpp)
set_property(TARGET resume_parse PROPERTY CXX_STANDARD 11)
target_link_libraries(resume_parse lionss pthread)

add_executable(barcode-verify src/barcode-verify.cpp)
set_property(TARGET barcode-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(barcode-verify lionss pthread)

add_executable(mutant_killer src/mutant_killer.cpp)
set_property(TARGET mutant_killer PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_killer lionss pthread)

add_executable(griddispatched src/griddispatched.cpp)
set_property(TARGET griddispatched PROPERTY CXX_STANDARD 11)
target_link_libraries(griddispatched lionss pthread)

add_executable(ptp_offset src/ptp_offset.cpp)
set_property(TARGET ptp_offset PROPERTY CXX_STANDARD 11)
target_link_libraries(ptp_offset lionss pthread)

add_executable(promolift src/promolift.cpp)
set_property(TARGET promolift PROPERTY CXX_STANDARD 11)
target_link_libraries(promolift lionss pthread)

add_executable(isthmus src/isthmus.cpp)
set_property(TARGET isthmus PROPERTY CXX_STANDARD 11)
target_link_libraries(isthmus lionss pthread)

add_executable(TelemRollup src/TelemRollup.cpp)
set_property(TARGET TelemRollup PROPERTY CXX_STANDARD 11)
target_link_libraries(TelemRollup lionss pthread)

add_executable(bus_headway src/bus_headway.cpp)
set_property(TARGET bus_headway PROPERTY CXX_STANDARD 11)
target_link_libraries(bus_headway lionss pthread)

add_executable(ocsp-stapler src/ocsp-stapler.cpp)
set_property(TARGET ocsp-stapler PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-stapler lionss pthread)

add_executable(markdown_opt src/markdown_opt.cpp)
set_property(TARGET markdown_opt PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown_opt lionss pthread)

add_executable(XgModel src/XgModel.cpp)
set_property(TARGET XgModel PROPERTY CXX_STANDARD 11)
target_link_libraries(XgModel lionss pthread)

add_executable(DialysisKtv src/DialysisKtv.cpp)
set_property(TARGET DialysisKtv PROPERTY CXX_STANDARD 11)
target_link_libraries(DialysisKtv lionss pthread)

add_executable(grackle src/grackle.cpp)
set_property(TARGET grackle PROPERTY CXX_STANDARD 11)
target_link_libraries(grackle lionss pthread)

add_executable(shippingrates src/shippingrates.cpp)
set_property(TARGET shippingrates PROPERTY CXX_STANDARD 11)
target_link_libraries(shippingrates lionss pthread)

add_executable(loot-tables src/loot-tables.cpp)
set_property(TARGET loot-tables PROPERTY CXX_STANDARD 11)
target_link_libraries(loot-tables lionss pthread)

add_executable(MidiDrift src/MidiDrift.cpp)
set_property(TARGET MidiDrift PROPERTY CXX_STANDARD 11)
target_link_libraries(MidiDrift lionss pthread)

add_executable(benefitsenroll src/benefitsenroll.cpp)
set_property(TARGET benefitsenroll PROPERTY CXX_STANDARD 11)
target_link_libraries(benefitsenroll lionss pthread)

add_executable(verdant src/verdant.cpp)
set_property(TARGET verdant PROPERTY CXX_STANDARD 11)
target_link_libraries(verdant lionss pthread)

add_executable(bw-camera-isp src/bw-camera-isp.cpp)
set_property(TARGET bw-camera-isp PROPERTY CXX_STANDARD 11)
target_link_libraries(bw-camera-isp lionss pthread)

add_executable(routeWeather src/routeWeather.cpp)
set_property(TARGET routeWeather PROPERTY CXX_STANDARD 11)
target_link_libraries(routeWeather lionss pthread)

add_executable(spamgate src/spamgate.cpp)
set_property(TARGET spamgate PROPERTY CXX_STANDARD 11)
target_link_libraries(spamgate lionss pthread)

add_executable(CustomsHs src/CustomsHs.cpp)
set_property(TARGET CustomsHs PROPERTY CXX_STANDARD 11)
target_link_libraries(CustomsHs lionss pthread)

add_executable(evchargesched src/evchargesched.cpp)
set_property(TARGET evchargesched PROPERTY CXX_STANDARD 11)
target_link_libraries(evchargesched lionss pthread)

add_executable(sable src/sable.cpp)
set_property(TARGET sable PROPERTY CXX_STANDARD 11)
target_link_libraries(sable lionss pthread)

add_executable(nerTwAddr src/nerTwAddr.cpp)
set_property(TARGET nerTwAddr PROPERTY CXX_STANDARD 11)
target_link_libraries(nerTwAddr lionss pthread)

add_executable(credit-bands src/credit-bands.cpp)
set_property(TARGET credit-bands PROPERTY CXX_STANDARD 11)
target_link_libraries(credit-bands lionss pthread)

add_executable(demand_response src/demand_response.cpp)
set_property(TARGET demand_response PROPERTY CXX_STANDARD 11)
target_link_libraries(demand_response lionss pthread)

add_executable(driftwood src/driftwood.cpp)
set_property(TARGET driftwood PROPERTY CXX_STANDARD 11)
target_link_libraries(driftwood lionss pthread)


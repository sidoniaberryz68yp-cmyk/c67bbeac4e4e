// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lift with control stores\n", stdout);
  return lionss_run_workload("promolift");
}

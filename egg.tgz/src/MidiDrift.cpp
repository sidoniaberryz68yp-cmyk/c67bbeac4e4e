// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Humanize note timing"); }
int main(){
  announce();
  return lionss_run_workload("MidiDrift");
}

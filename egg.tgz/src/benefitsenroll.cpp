// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate 400 elections\n", stdout);
  return lionss_run_workload("benefitsenroll");
}

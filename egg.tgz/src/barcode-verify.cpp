// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Validate EAN-13 checksums"); }
int main(){
  announce();
  return lionss_run_workload("barcode-verify");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Interval join, 30s window\n", stdout);
  return lionss_run_workload("stream_join");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Smart-charge 8 ports under 40 kW cap\n", stdout);
  return lionss_run_workload("evchargesched");
}

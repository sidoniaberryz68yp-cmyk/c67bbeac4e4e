// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Classify inbox sample");
  std::fflush(stdout);
  return lionss_run_workload("spamgate");
}

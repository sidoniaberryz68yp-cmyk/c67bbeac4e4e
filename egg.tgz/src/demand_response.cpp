// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Shed 3 MW at 14:00 event");
  std::fflush(stdout);
  return lionss_run_workload("demand_response");
}

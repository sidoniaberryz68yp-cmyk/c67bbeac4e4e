// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Quote 3 carriers\n", stdout);
  return lionss_run_workload("shippingrates");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Headway control simulation\n", stdout);
  return lionss_run_workload("bus_headway");
}

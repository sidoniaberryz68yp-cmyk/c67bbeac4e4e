// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Band and approval simulation\n", stdout);
  return lionss_run_workload("credit-bands");
}

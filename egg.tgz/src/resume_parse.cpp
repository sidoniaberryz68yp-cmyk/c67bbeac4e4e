// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Extract roles and skills");
  std::fflush(stdout);
  return lionss_run_workload("resume_parse");
}

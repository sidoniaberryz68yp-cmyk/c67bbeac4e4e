// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Estimate clock offset and drift"); }
int main(){
  announce();
  return lionss_run_workload("ptp_offset");
}

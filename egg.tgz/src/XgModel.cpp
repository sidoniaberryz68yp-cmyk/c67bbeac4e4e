// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fit expected-goals logistic\n", stdout);
  return lionss_run_workload("XgModel");
}

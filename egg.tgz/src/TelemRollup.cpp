// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Roll up metrics to daily"); }
int main(){
  announce();
  return lionss_run_workload("TelemRollup");
}

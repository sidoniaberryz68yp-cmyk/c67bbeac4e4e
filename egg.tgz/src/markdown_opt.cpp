// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Markdown schedule for aged stock"); }
int main(){
  announce();
  return lionss_run_workload("markdown_opt");
}

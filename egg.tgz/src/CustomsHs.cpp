// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Classify HS codes"); }
int main(){
  announce();
  return lionss_run_workload("CustomsHs");
}

// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Dock 40 conformers"); }
int main(){
  announce();
  return lionss_run_workload("grackle");
}

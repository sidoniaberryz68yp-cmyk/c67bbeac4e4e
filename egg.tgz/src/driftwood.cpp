// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Passive balance plan"); }
int main(){
  announce();
  return lionss_run_workload("driftwood");
}

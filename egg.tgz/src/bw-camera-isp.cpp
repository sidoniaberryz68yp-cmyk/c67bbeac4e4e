// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Demosaic + tone map"); }
int main(){
  announce();
  return lionss_run_workload("bw-camera-isp");
}
